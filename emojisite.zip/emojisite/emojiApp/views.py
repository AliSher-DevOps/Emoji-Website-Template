from django.shortcuts import redirect, render


def view_home(request):
    return render( request, 'index.html', )
