from django.conf.urls import url
from django.conf import settings
# import views all files

from . import views
from django.urls import path, include

urlpatterns = [
                  # -----------------------------URLS----------------------------
                  path( 'home', views.view_home, name='home' ),
              ]